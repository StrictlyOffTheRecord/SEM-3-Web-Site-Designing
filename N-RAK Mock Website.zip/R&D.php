<!doctype html>

<html>
 
	<head>

		<title>
			R&D
		</title>
		
		<link rel="stylesheet" type="text/css" href="./css/departmentlogo.css" />
		<link rel="stylesheet" type="text/css" href="./css/hover_button_blue.css" />
		<link rel="stylesheet" type="text/css" href="./css/form.css" />
	
	
	</head>

	
	<body>
	
		<div id="NRAK_HEAD">
		
			<img src="./Images/mainlogo.PNG" height="100"  />
		
		</div>  
		
		<div id="cosmeticslogo">
			
			<img src="./Images/R&D.PNG" height="250"  />
			
		</div>
		<?php
          require 'db.php';

          $sql="Select weapon_id,status,type,weapon_name from weaponry;";
          $result=mysql_query($sql);
          echo "<br>". "<br>". "<br>"."<br>" ."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>";
          echo "ID  STATUS TYPE  NAME ";
          while($row=mysql_fetch_array($result)){
          echo "<br>"; 
          echo $row['weapon_id']." "." ".$row['status']." "." ".$row['type']." "." ".$row['weapon_name'];
          echo "<br>";
          }
        ?>
        <div>
	    <table>
			<tr>
				<button type="button" onclick="location.href='ShowCase.html'">Back To Showcase page</button><BR><BR>
			<tr/>
	    </table>
        </div>
	
	
	</body>
	
</html>