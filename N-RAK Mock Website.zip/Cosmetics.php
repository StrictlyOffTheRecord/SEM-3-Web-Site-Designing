<!doctype html>

<html>

	<head>
 
		<title>
			Cosmetics
		</title>
		
		<link rel="stylesheet" type="text/css" href="./css/departmentlogo.css" />
		<link rel="stylesheet" type="text/css" href="./css/hover_button_blue.css" />
		<link rel="stylesheet" type="text/css" href="./css/form.css" />
	
	
	</head>

	
	<body>
	
		<div id="NRAK_HEAD">
		
			<img src="./Images/mainlogo.PNG" height="100"  />
		
		</div>  
		
		<div id="cosmeticslogo">
			
			<img src="./Images/Cosmetics.PNG" height="250"  />
			
		</div>
		<?php
          require 'db.php';

          $sql="Select cosmetics_product_id,type,cosmetic_name,price from cosmetics;";
          $result=mysql_query($sql);
          echo "<br>". "<br>". "<br>"."<br>" ."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>";
          echo "ID   TYPE  NAME  PRICE ";
          while($row=mysql_fetch_array($result)){
          echo "<br>"; 
          echo $row['cosmetics_product_id']." "." ".$row['type']." "." ".$row['cosmetic_name']." "." ".$row['price'];
          echo "<br>";
          }
        ?>
        <div>
	    <table>
			<tr>
				<button type="button" onclick="location.href='ShowCase.html'">Back To Showcase page</button><BR><BR>
			<tr/>
	    </table>
        </div>
	
	</body>
	
</html>