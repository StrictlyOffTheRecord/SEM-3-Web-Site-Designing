<!doctype html>

<html>

	<head>

		<title>
			Construction
		</title>
		
		<link rel="stylesheet" type="text/css" href="./css/departmentlogo.css" />
		<link rel="stylesheet" type="text/css" href="./css/hover_button_blue.css" />
		<link rel="stylesheet" type="text/css" href="./css/form.css" />
	
	
	</head>

	
	<body>
	
		<div id="NRAK_HEAD">
		
			<img src="./Images/mainlogo.PNG" height="100"  />
		
		</div>  
		
		<div id="cosmeticslogo">
			
			<img src="./Images/Construction.PNG" height="250"  />
			
		</div> 
	 	
	<?php
          require 'db.php';

          $sql="Select construction_project_id,building_type,building_name from construction;";
          $result=mysql_query($sql);
          echo "<br>". "<br>". "<br>"."<br>" ."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>";
          echo "ID   TYPE  NAME  ";
          while($row=mysql_fetch_array($result)){
          echo "<br>"; 
          echo $row['construction_project_id']." "." ".$row['building_type']." "." ".$row['building_name'];
          echo "<br>";
          }
        ?>
        <div>
	    <table>
			<tr>
				<button type="button" onclick="location.href='ShowCase.html'">Back To Showcase page</button><BR><BR>
			</tr>
	    </table>
        </div>
	</body>
	
</html>