<!doctype html>

<html>

	<head>

		<title>
			Clothing
		</title>
		
		<link rel="stylesheet" type="text/css" href="./css/departmentlogo.css" />
		<link rel="stylesheet" type="text/css" href="./css/hover_button_blue.css" />
		<link rel="stylesheet" type="text/css" href="./css/form.css" />
	
	
	</head>

	
	<body>
	
		<div id="NRAK_HEAD">
		
			<img src="./Images/mainlogo.PNG" height="100"  />
		
		</div>  
		
		<div id="cosmeticslogo">
			
			<img src="./Images/ClothingLogo.PNG" height="250"  />
			
		</div>
		<?php 
require 'db.php';

$sql="Select clothing_id,clothing_type,gender,color,size,price from clothing;";
$result=mysql_query($sql);
echo "<br>". "<br>". "<br>"."<br>" ."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>"."<br>";
echo "CLOTHING_ID   CLOTHING_TYPE   GENDER  COLOR  SIZE  PRICE ";
while($row=mysql_fetch_array($result)){
echo "<br>"; 
echo $row['clothing_id']." "." ".$row['clothing_type']." "." ".$row['gender']." "." ".$row['color']." "." ".$row['size']." "." ".$row['price'];
echo "<br>";
}
?>
<div>
	<table> 
			<tr>
				<button type="button" onclick="location.href='ShowCase.html'">Back To Showcase page</button><BR><BR>
			<tr/>
	</table>
</div>
	</body>
	
</html>