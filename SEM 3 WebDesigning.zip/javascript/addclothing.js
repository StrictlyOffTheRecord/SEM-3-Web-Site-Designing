function validate()
{
	if(document.sign_up_form.id.value=="")
	{
		alert('Clothing ID is Required');
		return false;
	}

	if(document.sign_up_form.type.value=="")
	{
		alert('Clothing Type is Required');
		return false;
	}

	if(document.sign_up_form.gender.value=="")
	{
		alert('Gender is Required');
		return false;
	}

	if(document.sign_up_form.color.value=="")
	{
		alert('Color is Required');
		return false;
	}

	if(document.sign_up_form.size.value=="")
	{
		alert('Size is Required');
		return false;
	}

	if(document.sign_up_form.price.value=="")
	{
		alert('Price is Required');
		return false;
	}

	if(!document.sign_up_form.id.value.match(/^[0-9]+$/))
	{
		alert('Clothing ID can anly contain numbers!');
		return false;
	}
	
	if(!document.sign_up_form.type.value.match(/^[A-Z a-z]+$/))
	{
		alert('Clothing Type can anly contain alphabets!');
		return false;
	}
	
	if(!document.sign_up_form.gender.value.match(/^[A-Z a-z]+$/))
	{
		alert('Gender can anly contain alphabets!');
		return false;
	}
	
	if(!document.sign_up_form.color.value.match(/^[A-Z a-z]+$/))
	{
		alert('Color can anly contain alphabets!');
		return false;
	}
	
	if(!document.sign_up_form.size.value.match(/^[A-Z a-z]+$/))
	{
		alert('Size can anly contain alphabets!');
		return false;
	}
	
	if(!document.sign_up_form.price.value.match(/^[0-9]+$/))
	{
		alert('Price can anly contain numbers!');
		return false;
	}

	return true;
}