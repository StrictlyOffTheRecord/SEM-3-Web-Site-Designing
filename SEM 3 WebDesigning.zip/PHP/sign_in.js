function validate()
{
	if(document.sign_in_form.user_id.value=="")
	{
		alert('User ID is Required');
		return false;
	}

	if(document.sign_in_form.password.value=="")
	{
		alert('Password is Required');
		return false;
	}

	return true;
}