<?php
	
	require 'connect_to_database.php';

	//creating a table query to send to MySQL

	$sql = "CREATE TABLE Profile
			(
				Name varchar(25),
				UserID varchar(10) PRIMARY KEY,
				Password varchar(64)
			)";

	//Execute the query
	//con is the variable to connect to MySQL and contains mysql_connect
	mysql_query($sql,$con);

?>