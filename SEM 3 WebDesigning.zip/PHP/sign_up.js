function validate()
{
	if(document.sign_up_form.fullname.value=="")
	{
		alert('User Name is Required');
		return false;
	}

	if(document.sign_up_form.user_id.value=="")
	{
		alert('User ID is Required');
		return false;
	}

	if(document.sign_up_form.password.value=="")
	{
		alert('Password is Required');
		return false;
	}

	if(!document.sign_up_form.fullname.value.match(/^[A-Z a-z]+$/))
	{
		alert('Name can anly contain alphabets!');
		return false;
	}

	if(!document.sign_up_form.user_id.value.match(/^[0-9]+$/))
	{
		alert('User ID can anly contain numbers!');
		return false;
	}

	return true;
}