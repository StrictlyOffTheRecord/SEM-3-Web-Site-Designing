<html>

	<head>

		<title>
			Record Inserted
		</title>

		<link rel="stylesheet" type="text/css" href="form.css">

		<style>

			#record_inserted_form_div
			{
				position: absolute;
				top: 100px;
				left: 400px;
			}

		</style>
	
	</head>

		<?php
			include 'connect_to_database.php';

			$fullname = $_POST['fullname'];
			$id = $_POST['user_id'];
			$password = $_POST['password'];

			$sql = "INSERT INTO Profile(Name,userID,Password) VALUES('$fullname',$id,'$password')";

			if(!mysql_query($sql,$con))
			{
				die('Error:'.mysql_error());
			}

		?>
		
	<body>


		<div id="record_inserted_form_div">
			<form class="form-container" name="record_inserted_form">
					
				<div class="form-title"><h2>Record Is Inserted</h2></div>

				<div class="submit-container">
			
				<input class="submit-button" type="button" value="Return To Index" onclick="location.href='Buttons.html'"/>
				
				</div>

			</form>
		</div>
	
	</body>

</html>