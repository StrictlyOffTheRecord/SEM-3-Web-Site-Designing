<?php
	$host="localhost";
	$user="root";
	$password="";
	
	//command to connect to MySQL
	$con=mysql_connect($host,$user,$password);

	if(!$con)
	{
		die('Could Not Connect to MySQL Server '.mysql_error());
	}

	else
	{
		//echo "Connected to MySQL Server";

		$database_name="sem3";
		//command to use a perticular database
		$database=@mysql_select_db($database_name,$con) or die('Database not found '.mysql_error());
	}
?>