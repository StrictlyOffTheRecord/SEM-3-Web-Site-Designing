<html>
	
	<head>

		<link rel="stylesheet" type="text/css" href="form.css" />

		<style type="text/css">

			#Profile_div
			{
				position: relative;
				top:200px;
				left:400px;
			}

		</style>

	</head>
	


	<body>
		
		<?php
			require 'connect_to_database.php';
			$id=$_POST['user_id'];
			$password=$_POST['password'];

			$sql="SELECT * from Profile 
					/*where UserID='$id'
					and Password='$password'*/;";

			$result=mysql_query($sql);
			
			
			while($row = mysql_fetch_array($result))
			{
				$a= $row['Name'];
				$b= $row['UserID'];
				$c= $row['Password'];
				echo"<div id='Profile_div'>";

				echo"<form class='form-container' name='profile'>";
			
				echo"<div class='form-title'><h2>Profile</h2></div>";
			
				echo"<div class='form-title'>Name:" .$a ."</div>";
			
				echo"<div class='form-title'>User ID:"  .$b. "</div>";
			
				echo"<div class='form-title'>Password:"  .$c."</div>";
			
		
				echo"</form>";

				echo"</div>";
				
				echo"<br /><br />";
			}
		?>

		

	</body>

</html>