create database nrak;
use nrak;


create table department
(
	id varchar(5) primary key,
    dept_name varchar(20) ,
	location varchar(60),
    year_of_creation varchar(4),
	years_active int
);


create table weaponry
(
	dept_id varchar(6) ,
	weapon_id varchar(4) primary key,
	weapon_status varchar(4),
	weapon_type varchar(8),
	weapon_name varchar(20),
	foreign key (dept_id) references department(id)
);


create table cosmetics
(
	dept_id varchar(6),
	cosmetics_product_id varchar(4) primary key,
	cosmetics_type varchar(8),
	cosmetic_name varchar(20),
	price decimal(3,2),
	foreign key (dept_id) references department(id)
);



create table healthcare 
(
	hospital_id varchar(4) primary key,
	dept_id varchar(6),
	hospital_name varchar(20),
	year_est varchar(4),
	foreign key(dept_id) references department(id)
);


create table construction
(
	e_id varchar(6),
	construction_project_id varchar(4) primary key,
	building_type varchar(8),
	building_name varchar(20),
	foreign key (e_id) references department(id)
);



create table clothing
(
	c_id varchar(6) not null,
	clothing_id varchar(4) primary key,
	clothing_type varchar(4),
	gender varchar(1),
	color varchar(6),
	size varchar(3),
	price decimal(3,2),
	foreign key (c_id) references department(id)
);



create table education
(
	dept_id varchar(6),
	school_id varchar(4) primary key,
	school_name varchar(20),
	year_est integer(4),
	foreign key(dept_id) references department(id)
);


/*
	SUPER CLASS DEPARTMENT ENDS
*/


create table employee
(
	id varchar(4) primary key,
	emp_name varchar(20),
	year_joined integer(4),
	job_type varchar(8),
	salary decimal(10,2),
	dept_id varchar(6),
	foreign key (dept_id) references department(id)
);


create table doctor
(
     emp_id varchar(4),
     hospital_id varchar(4),
     foreign key(emp_id) references employee(id),
     foreign key(hospital_id) references healthcare(hospital_id)
);



create table nurse
(
     emp_id varchar(4),
     hospital_id varchar(4),
     foreign key(emp_id) references employee(id),
     foreign key(hospital_id) references healthcare(hospital_id)
);


create table teacher
(
	emp_id varchar(4),
	school_id varchar(4),
    foreign key(emp_id) references employee(id),
    foreign key(school_id) references education(school_id)
);


create table fashion_designer
(
	emp_id varchar(4),
    clothing_id varchar(4),
    foreign key(emp_id) references employee(id),
    foreign key(clothing_id) references clothing(clothing_id)
);


create table labour
(
     emp_id varchar(4),
     d_id varchar(5),
     foreign key(emp_id) references employee(id),
     foreign key(d_id) references department(id)
);


create table peon
(
     emp_id varchar(4),
     d_id varchar(5),
     foreign key(emp_id) references employee(id),
     foreign key(d_id) references department(id)
);


create table CEO
(
     emp_id varchar(4),
     foreign key(emp_id) references employee(id)
);


create table engineer
(
    emp_id varchar(4),
    dept_id varchar(5),
    eng_id varchar(4) PRIMARY KEY,
    foreign key(emp_id) references employee(id),
	foreign key(dept_id) references department(id)
);


create table cs_engineer
(
    weapon_id varchar(4),
    eng_id varchar(4),
    foreign key(weapon_id) references weaponry(weapon_id),
    foreign key(eng_id) references engineer(eng_id)
);



create table elec_engineer
(
    weapon_id varchar(4),
    eng_id varchar(4),
    foreign key(weapon_id) references weaponry(weapon_id),
    foreign key(eng_id) references engineer(eng_id)
);



create table civil_engineer
(
	construction_project_id varchar(4),
    eng_id varchar(4),
    foreign key(eng_id) references engineer(eng_id),
    foreign key(construction_project_id) references construction(construction_project_id)
);


create table mech_engineer
(
    weapon_id varchar(4),
    eng_id varchar(4),
    foreign key(weapon_id) references weaponry(weapon_id),
    foreign key(eng_id) references engineer(eng_id)
);


create table manager
(
    emp_id varchar(4),
    dept_id varchar(5),
    foreign key(emp_id) references employee(id),
    foreign key(dept_id) references department(id)
);


