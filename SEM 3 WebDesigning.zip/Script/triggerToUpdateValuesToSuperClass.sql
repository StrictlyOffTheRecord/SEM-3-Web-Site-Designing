create database practice;
use practice;

create table k1
(
	id int primary key,
    address int
);

create table p1
(
	id int primary key,
    address int ,
    roll int
);



delimiter //
create trigger updatingK
after insert on p1
for each row


begin

	insert into k1
	select id, address
    from p1;
    

end //

delimiter ;

insert into p1 values(1,114,007);


